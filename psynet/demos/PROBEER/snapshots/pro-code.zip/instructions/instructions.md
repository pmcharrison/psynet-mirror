In this study we want to understand how people express intentions with their voice.
During the experiment you will listen to the word 'bier'. Your task is to make the word sound like a criticism or 
a suggestion. You can modify the voice by moving the slider. Go to the next page to get comfortable with the slider.