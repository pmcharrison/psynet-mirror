Here is a situation in which a speaker would say the word 'beer' as a criticism. Please read the scenario carefully and keep it in mind when moving the slider <br>
<br>
A friend of yours disapprovingly criticises an idea you have. Your colleague Anna and you will present your first big 
job in an important meeting with all department heads in a few minutes. Anna is extremely nervous because a lot is at 
stake. Both of you are very well prepared, so you are thinking that there is some time left to relax and you 
spontaneously express the idea to get two bottles of beer from the fridge. Anna asks you disapprovingly: <br>
<b>(Are you sure? Now a) beer?</b>