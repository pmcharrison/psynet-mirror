Here is a situation in which a speaker would say the word 'beer' as a suggestion. Please read the scenario carefully and keep it in mind when moving the slider <br>
<br>
A good colleague of yours invitingly proposes to undertake something together.  It is Thursday evening and you have 
almost finished your work. You and your colleague Anna achieved a lot today and are satisfied with your work.  Just now 
you see Anna happily approaching you and can already guess what will happen because you often go to your favourite bar 
together after work. Indeed, she peeks into your office and asks invitingly: <br>
<b>(Are you up for a) beer?</b>